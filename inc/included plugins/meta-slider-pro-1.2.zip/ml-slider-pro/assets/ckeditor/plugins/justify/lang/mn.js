﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'mn', {
	block: 'Тэгшлэх',
	center: 'Голлуулах',
	left: 'Зүүн талд тулгах',
	right: 'Баруун талд тулгах'
});
