﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'el', {
	block: 'Πλήρης Στοίχιση',
	center: 'Στοίχιση στο Κέντρο',
	left: 'Στοίχιση Αριστερά',
	right: 'Στοίχιση Δεξιά'
});
