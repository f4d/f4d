﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'sourcedialog', 'gu', {
	toolbar: 'મૂળ કે પ્રાથમિક દસ્તાવેજ',
	title: 'મૂળ કે પ્રાથમિક દસ્તાવેજ'
});
