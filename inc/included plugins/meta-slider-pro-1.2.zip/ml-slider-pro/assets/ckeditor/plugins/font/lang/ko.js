﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'ko', {
	fontSize: {
		label: '글자 크기',
		voiceLabel: 'Font Size',
		panelTitle: '글자 크기'
	},
	label: '폰트',
	panelTitle: '폰트',
	voiceLabel: '폰트'
});
